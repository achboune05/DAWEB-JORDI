# Monthly progress report
Student and month:
Review tag:
## What works now
Describe the current service and the result you can show. Mention unfinished work honestly.
## How I built and deployed it
Explain the main path and one choice you made. Refer to source, live files and versions.
## A problem or risk I investigated
Describe the symptom or risk, useful check, result and repair or decision. Do not invent a fault.
## How I know it works
Refer to the five monthly checks and a few actual files or live results. Avoid repeating long output.
## Next steps and limitations
State the most useful next action and any remaining technical or infrastructure block.
Normally one or two pages; maximum three. No daily diary or screenshot quota.
