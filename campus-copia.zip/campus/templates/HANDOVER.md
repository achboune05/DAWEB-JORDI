# Campus service handover
Author and final revision:
This file is required in M05 only. Aim for four to six useful pages.
## Machines names ports and important paths
## Start services and verify the client routes
## Publish and roll back the portal
## Rebuild and deploy the Java WAR
## Back up and restore persistent data
## Reissue lab certificates and verify client trust
## Diagnose three common problems
For each action: location, command, expected result and next check if it differs.
## Tested boundaries and limitations
Separate a tested data restoration from an untested complete VM rebuild.
## Partner handover result
Three tasks attempted, one missing instruction, revision and actual retest outcome.
No passwords or private keys.
