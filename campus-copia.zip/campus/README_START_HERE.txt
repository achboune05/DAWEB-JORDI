CAMPUS EVENTS - MISSION EDITION - 30 OCTOBER 2026
Use the revised English guide. Start with Mission 01; open the P help procedures when needed.
Choose a fictional club identity. Keep common paths and names so all help remains usable.
Extract campus-starter inside the SERVER Ubuntu VM and move it to /home/student/campus.
If campus already exists, use UPDATE_EXISTING_LAB.txt instead of replacing your project.
portal/      editable static site
app/         supplied PHP application and database initializer
java/        supplied JSP to build into campus.war
config/      public configuration copied only at the stated procedure
scripts/     readable build, deployment, checking and packaging helpers
templates/   monthly report and final handover only
There is no daily diary, daily quiz or screenshot collection to submit.
Each month hand in current files, a short report and the five concise checks from the guide.
Screenshots are optional, at most three relevant images per month.
Use fictional data only. Keep keys and passwords private. No paid or public hosting is required.
Original sample files may be adapted and redistributed for classroom use.
Third-party Ubuntu, Apache, PHP, Tomcat and other software retain their own licences.
