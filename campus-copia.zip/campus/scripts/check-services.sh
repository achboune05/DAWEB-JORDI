#!/usr/bin/env bash
set -uo pipefail
failures=0
for url in http://portal.test/ http://app.test/ http://java.test/campus/; do
    host="${url#http://}"; host="${host%%/*}"
    if curl --noproxy '*' --fail --silent --show-error --max-time 8 --resolve "$host:80:127.0.0.1" "$url" >/dev/null; then
        echo "PASS $url"
    else
        echo "FAIL $url"; failures=$((failures+1))
    fi
done
exit "$failures"
