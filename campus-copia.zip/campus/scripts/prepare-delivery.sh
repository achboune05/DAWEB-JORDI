#!/usr/bin/env bash
set -euo pipefail
if [[ $# -ne 3 ]]; then
  echo 'Usage: bash scripts/prepare-delivery.sh M01 StudentID M01-r1' >&2; exit 2
fi
month="$1"; student_id="$2"; tag="$3"
[[ "$month" =~ ^M0[1-5]$ ]] || { echo 'Month must be M01 to M05' >&2; exit 2; }
[[ "$student_id" =~ ^[A-Za-z0-9][A-Za-z0-9_-]{0,39}$ ]] || { echo 'Use an identifier with letters numbers hyphens or underscores' >&2; exit 2; }
[[ "$tag" =~ ^${month}-r[1-9][0-9]*$ ]] || { echo 'Use a review tag matching the month, for example M01-r1' >&2; exit 2; }
n=$((10#${month:1:2}))
cd "$HOME/campus"
git rev-parse --verify "refs/tags/$tag" >/dev/null
[[ "$(git rev-parse HEAD)" == "$(git rev-parse "$tag^{commit}")" ]] || { echo 'HEAD differs from the review tag. Commit and use a new review revision.' >&2; exit 3; }
git diff --quiet && git diff --cached --quiet || { echo 'Commit the intended tracked changes before preparing the delivery.' >&2; exit 3; }
[[ -z "$(git ls-files --others --exclude-standard)" ]] || { echo 'Untracked public files exist. Review git status and commit intended source files first.' >&2; exit 3; }
# Inspect filenames in all history before creating a portable history bundle.
history_paths="$(git log --all --name-only --format=)"
if grep -Eq '(^|/)(private|backups)/|\.(key|pem|p12|sqlite|sqlite3|db)$|(^|/)\.env($|\.)' <<< "$history_paths"; then
  echo 'A private or data filename is present in Git history. Ask the teacher before bundling it.' >&2; exit 4
fi
dest="$HOME/deliveries/$tag-$student_id"
if [[ -e "$dest" ]]; then echo 'Delivery folder exists. Keep it and use a new review revision.' >&2; exit 5; fi
umask 077
mkdir -p "$dest/source" "$dest/runtime" "$dest/proof"
git archive "$tag" | tar -xf - -C "$dest/source"
git bundle create "$dest/history.bundle" --all
cp templates/MONTHLY_REPORT.md "$dest/report.md"
copy_required() {
  local src="$1"
  if ! sudo test -f "$src"; then echo "Required file missing: $src. Preserve this partial folder and complete the prerequisite." >&2; exit 6; fi
  sudo cat "$src" > "$dest/runtime/$(basename "$src")"
}
copy_required /etc/apache2/sites-available/campus-portal.conf
if (( n >= 2 )); then
  copy_required /etc/apache2/sites-available/campus-app.conf
  for file in named.conf.options named.conf.local db.campus.test; do copy_required "/etc/bind/$file"; done
  mkdir -p "$dest/recovery"
  sudo sqlite3 /var/lib/campus/events.sqlite ".backup '$dest/recovery/events.sqlite'"
  sudo chown student:student "$dest/recovery/events.sqlite"
  chmod 600 "$dest/recovery/events.sqlite"
  sqlite3 "$dest/recovery/events.sqlite" 'PRAGMA integrity_check;' > "$dest/recovery/integrity.txt"
  (cd "$dest/recovery" && sha256sum events.sqlite > SHA256.txt)
fi
if (( n >= 3 )); then
  copy_required /etc/apache2/sites-available/campus-java.conf
  copy_required /etc/tomcat10/server.xml
  [[ -f build/campus.war ]] || { echo 'Build the current Java source into build/campus.war first.' >&2; exit 6; }
  mkdir -p "$dest/artifacts"
  cp build/campus.war "$dest/artifacts/"
  (cd "$dest/artifacts" && sha256sum campus.war > SHA256.txt)
fi
if (( n >= 4 )); then
  for site in portal app java; do copy_required "/etc/apache2/sites-available/campus-$site-tls.conf"; done
  copy_required /etc/vsftpd.conf
  sudo postconf -n > "$dest/runtime/postconf.txt"
  [[ -f campus-lab-ca.crt ]] || { echo 'Copy the public CA as campus-lab-ca.crt using P12.' >&2; exit 6; }
  cp campus-lab-ca.crt "$dest/runtime/"
fi
if (( n == 5 )); then
  copy_required /etc/cron.d/campus-backup
  sudo tail -n 20 /var/log/campus-backup.log > "$dest/proof/schedule-log.txt"
  cp templates/HANDOVER.md "$dest/runbook.md"
fi
{
  echo "Student: $student_id"
  echo "Month: $month"
  echo "Review tag: $tag"
  printf 'Review commit: '; git rev-parse "$tag^{commit}"
  printf 'SERVER hostname: '; hostname
  echo 'SERVER interfaces:'; ip -br addr
  printf 'Live portal target: '; readlink -f /var/www/campus/current || true
  echo 'Live PHP label observed from CLIENT: COMPLETE if applicable'
  echo 'Live Java label observed from CLIENT: COMPLETE if applicable'
  echo 'CLIENT hostname and internal IP: COMPLETE'
  echo 'Source/build/live differences: COMPLETE or write none after checking'
} > "$dest/versions.txt"
case "$month" in
  M01) checks=('Client portal and About page' 'Visible version update' 'Rollback and return to intended version' 'Two guest identities and temporary name mapping' 'SFTP copy and tagged source identity');;
  M02) checks=('Direct and system DNS without client hosts mapping' 'PHP save and reload' 'Code update preserves rows' 'Database stays outside public HTTP' 'Restore recorded data and write again');;
  M03) checks=('Local generated Java response' 'Client proxy works and direct 8080 is blocked' 'Java update rollback and intended version' 'Health check failure diagnosis and recovery' 'Unique request found in access log');;
  M04) checks=('Three HTTPS names verified without -k' 'FTPS upload/download hashes match' 'Plain anonymous FTP has no writable session' 'Local SMTP message actually delivered' 'Remote SMTP connection remains blocked');;
  M05) checks=('Observed schedule and final weekday configuration' 'Backup hash matches outside SERVER and host copy exists' 'Returned backup restores data and supports a new write' 'Measured recovery time and scope explained' 'Three partner tasks and one revised instruction retested');;
esac
{
  echo "$month monthly acceptance"
  echo 'Replace PENDING with actual PASS FAIL or PENDING and one concise supporting result.'
  for i in "${!checks[@]}"; do echo "$((i+1)). PENDING - ${checks[$i]}"; done
  echo 'Earlier service baseline retested: COMPLETE briefly; no duplicate screenshot collection.'
} > "$dest/proof/acceptance.txt"
echo "Prepared $dest"
echo 'This helper does not pass the practical checks. Complete report, acceptance and version labels.'
echo 'Inspect the folder and compress it with the P19 zip command.'
