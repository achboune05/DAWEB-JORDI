#!/usr/bin/env python3
from email.message import EmailMessage
import smtplib
m = EmailMessage()
m['From'] = 'student@localhost'
m['To'] = 'student@localhost'
m['Subject'] = 'Campus recovery check'
m.set_content('Local lab message. Record the queue ID and delivery result.')
with smtplib.SMTP('127.0.0.1', 25, timeout=10) as s:
    s.send_message(m)
print('Accepted by local SMTP. Check the mailbox to prove delivery.')
