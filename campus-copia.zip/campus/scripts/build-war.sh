#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/campus"
mkdir -p build
jar --create --file build/campus.war -C java .
jar --list --file build/campus.war
