#!/usr/bin/env python3
import xml.etree.ElementTree as ET
p = '/etc/tomcat10/server.xml'
tree = ET.parse(p)
items = [x for x in tree.getroot().iter('Connector') if x.get('port') == '8080']
if len(items) != 1:
    raise SystemExit('Expected one port 8080 Connector. No file changed.')
items[0].set('address', '127.0.0.1')
tree.write(p, encoding='utf-8', xml_declaration=True)
print('8080 connector limited to loopback')
