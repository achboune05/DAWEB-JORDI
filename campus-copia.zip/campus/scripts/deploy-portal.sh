#!/usr/bin/env bash
set -euo pipefail
cd "$HOME/campus"
tag="${1:-}"
if [[ ! "$tag" =~ ^m[1-5]-v[0-9]+$ ]]; then
    echo "Usage: bash scripts/deploy-portal.sh m1-v1" >&2; exit 2
fi
git rev-parse --verify "refs/tags/$tag" >/dev/null
release="/var/www/campus/releases/$tag"
if sudo test -e "$release"; then
    echo "Release already exists. Use a new tag or follow rollback instructions." >&2; exit 3
fi
sudo mkdir -p "$release"
git archive "$tag" portal | sudo tar -xf - -C "$release"
sudo chmod -R a+rX "$release"
sudo ln -s "$release/portal" /var/www/campus/current.next
sudo mv -Tf /var/www/campus/current.next /var/www/campus/current
echo "Published $tag. Validate the Apache site and test the page from CLIENT."
