#!/usr/bin/env bash
set -euo pipefail
if [[ $EUID -ne 0 ]]; then echo "Run with sudo" >&2; exit 2; fi
stamp="$(date -u +%Y%m%dT%H%M%S%NZ)"
work="$(mktemp -d)"
trap 'rm -rf -- "$work"' EXIT
install -d -o student -g student -m 700 /home/student/campus/backups
sqlite3 /var/lib/campus/events.sqlite ".backup '$work/events.sqlite'"
cp /home/student/campus/config/apache-*.conf "$work/"
cp /etc/bind/db.campus.test "$work/"
printf 'Created UTC %s
' "$stamp" > "$work/manifest.txt"
archive="/home/student/campus/backups/data-$stamp.tar.gz"
tar -czf "$archive" -C "$work" .
chown student:student "$archive"
chmod 600 "$archive"
sha256sum "$archive"
echo "Copy archive outside SERVER. This is a data backup, not a complete VM backup."
