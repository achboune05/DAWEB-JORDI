<?php
declare(strict_types=1);
$db = new PDO('sqlite:/var/lib/campus/events.sqlite');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->exec('CREATE TABLE IF NOT EXISTS requests (id INTEGER PRIMARY KEY, title TEXT NOT NULL, created_at TEXT NOT NULL)');
echo "Database ready
";
