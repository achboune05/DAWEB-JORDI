<?php
declare(strict_types=1);
session_start();
$_SESSION['csrf'] ??= bin2hex(random_bytes(24));
function esc(string $s): string { return htmlspecialchars($s, ENT_QUOTES, 'UTF-8'); }
try {
    $db = new PDO('sqlite:/var/lib/campus/events.sqlite');
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = (string)($_POST['csrf'] ?? '');
        $title = trim((string)($_POST['title'] ?? ''));
        if (!hash_equals($_SESSION['csrf'], $token) || $title === '' || strlen($title) > 120) {
            http_response_code(400); exit('Invalid request');
        }
        $q = $db->prepare('INSERT INTO requests (title, created_at) VALUES (?, ?)');
        $q->execute([$title, gmdate('c')]);
        header('Location: /', true, 303); exit;
    }
    $rows = $db->query('SELECT id, title, created_at FROM requests ORDER BY id DESC LIMIT 50')->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log($e->getMessage()); http_response_code(503); exit('Database unavailable');
}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Campus requests</title></head>
<body><h1>Campus requests</h1><p>App release M2 V1</p><p>Fictional events only.</p>
<form method="post"><label>Event title <input name="title" maxlength="120" required></label>
<input type="hidden" name="csrf" value="<?= esc($_SESSION['csrf']) ?>">
<button type="submit">Save event</button></form>
<ul><?php foreach ($rows as $row): ?>
<li>#<?= (int)$row['id'] ?> <?= esc($row['title']) ?> <?= esc($row['created_at']) ?></li>
<?php endforeach; ?></ul></body></html>
