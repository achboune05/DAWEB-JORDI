<%@ page contentType="text/html; charset=UTF-8" %>
<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Campus Java</title></head>
<body><h1>Campus Java service</h1><p>Java release M3 V1</p>
<p>Server time <%= java.time.Instant.now().toString() %></p></body></html>
